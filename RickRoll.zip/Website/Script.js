document.getElementById("myButton").onclick = function () {
    location.href = "www.yoursite.com";
};